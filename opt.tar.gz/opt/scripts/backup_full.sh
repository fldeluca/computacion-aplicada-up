#!/bin/bash

if [ "$1" == "-help" ]; then
	echo "Para usar este Script deberas indicar directorio de Origen y Destino"
	echo "Ejemplo: $0 /opt/scripts /backup_dir"
	echo "La funcion de este Script es realizar un backup desde un Origen hacia un Destino"
	exit 0
elif [ $# -ne 2 ]; then
	echo "Para usar este script necesita dos argumentos (dir. de origen y dir. de destino)"
	exit 1
fi

if [! -d "$1" ]; then
	echo "El directorio de origen es invalido o no existe"
	exit 1
elif [! -d "$2" ]; then
	echo "El directorio de destino es invalido o no existe"
	exit 1
fi

FECHA=$(date +%Y%m%d)
BACKUP=$(basename "$1")_bkp_$FECHA.tar.gz

tar -czf "$2/$BACKUP" -C "$1" .

if [$? -eq 0 ]; then
	echo "El backup fue creado exitosamente"
else
	echo "El backup no se pudo crear"
	exit 1

fi 


