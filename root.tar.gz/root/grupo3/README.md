# Computación Aplicada - Grupo 3

Trabajo práctico integrador grupal

## Integrantes

- Cabo Blanco, María Laura
- Deluca, Franco Leopoldo
- Olivera, Arianna
- Ravale, Emanuel Maximiliano Francisco
